package com.example.gocar;
public class AppConfig {
    // Server user login url
    public static String URL_LOGIN = "http://172.20.10.3/android_login_api/login.php";

    // Server user register url
    public static String URL_REGISTER = "http://172.20.10.3/android_login_api/register.php";

    //Vehicles url
    public static String URL_Vehicles = "http://172.20.10.3/android_login_api/vehicles.php";
    //Review in url
    public static String URL_Review_in = "http://172.20.10.3/android_login_api/reviewin.php";
    //Review out url
    public static String URL_Review_out = "http://172.20.10.3/android_login_api/reviewout.php";
}
